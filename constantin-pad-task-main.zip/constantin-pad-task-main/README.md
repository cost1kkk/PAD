# Microservice-based DnD Platform

## Deployment

**In order to run the app**, have Docker installed on your machine and execute the following command from the project root:
```
docker-compose up --build
```

## Data Structure (Entities)

1. The **Chat App** consists of two main entities: **chats(1) and messages(\*)**. Regarding the structure of messages, it is important to mention the presence of **two lists**: private and seen, both containing usernames.

    * The **private** list is used to target specific users within a chat. If the array is empty, all users in the chat receive the message when retrieving the chat. If the list is populated, only the users whose usernames are included will receive the message. **The chat service filters the messages delivered to each user based on the value in the _X-Username_ header.**

    * The **seen** list is used for an additional functionality that allows users to retrieve a list of chats with messages they have not seen. **This functionality also relies on the _X-Username_ header to determine which messages a user has viewed.**

2. The **Asset App** consists of two main entities: **scenes (\*) and assets (\*)**. Each scene is associated with various assets, so users can retrieve a list of the resources that need to be fetched in order to open the scene (in theory).

## Data Management Design (Endpoints)

### Chat Service endpoints:

1. GET / POST / PATCH / DELETE **/chats/** (handled by: chatApp.chats.views.ChatView) - **CRUD** fucntionality for the chat entity; GET lists just IDs and names

2. GET **/chats/:chat_id/** (handled by: chatApp.chats.views.ChatView) - **retrieve a detailed chat record with its messages list**; requires the _X-Username_ header to filter private messages specific to the user

3. GET **/chats/unseen-list/** (handled by: chatApp.chats.views.UnseenChatListView) - **list chats containing messages that are unseen by the user** specified in the _X-Username_ header

4. POST **/messages/send-to-chat/:chat_id/** (handled by: chatApp.messages.views.MessageView) - **post a message** to the chat specified by ID; the visibility of the message can be limited to specific users by providing a _private_ list

5. PATCH / DELETE **/messages/:message_id/** (handled by: chatApp.messages.views.MessageView) - partial **CRUD** functionality (without 'create' and 'read') for the message entity

6. PATCH **/messages/:message_id/mark-as-seen/** (handled by: chatApp.messages.views.MarkAsSeenView) - **mark a message as seen** by the user specified in the _X-Username_ header, identified by the message ID

7. GET **/chatApp/utilities/status/** (handled by: chatApp.utilities.views.StatusView) - required **status** endpoint

### Asset Service endpoints:


1. GET / POST / PATCH / DELETE **/scenes/** (handled by: assetApp.scenes.views.SceneView) - **CRUD** fucntionality for the scene entity; GET lists just IDs and names

2. GET **/scenes/:scene_id/** (handled by: assetApp.scenes.views.SceneView) - **retrieve a detailed scene record with its assets list**

3. GET / POST / PATCH / DELETE **/scenes/** (handled by: assetApp.assets.views.AssetView) - **CRUD** fucntionality for the asset entity; GET lists just IDs and names

4. GET **/assets/:asset_id/** (handled by: assetApp.assets.views.AssetView) -  **retrieve a detailed asset record**

5. POST **/assets/:asset_id/add-to-scene/:scene_id/** (handled by: assetApp.assets.views. AddAssetToSceneView) - create a scene-asset mapping, **adding the asset to the scene's resources**

6. GET **/assets/list-for-scene/:scene_id/** (handled by: assetApp.assets.views. ListAssetsForScene) - **list all the assets associated with the scene** specified by ID

7. GET **/assets/get-file-url/:asset_id/** (handled by: assetApp.assets.views. GetFileUrlView) - **retrieve the file URL** for an asset specified by its ID

8. GET **/assetApp/utilities/status/** (handled by: assetApp.utilities.views.StatusView) - required **status** endpoint

## Gateway

### Load Balancing

Load balancing is achieved by cycling through a list of available hosts before each request, selecting an IP to redirect the request.

```JavaScript
const chatBases = ["http://chat-1:8000", "http://chat-2:8000", "http://chat-3:8000"];
const assetBases = ["http://asset-1:8000", "http://asset-2:8000", "http://asset-3:8000"];
let chatIndex = 0;
let assetIndex = 0;

const getNextHost = (serviceHosts, index) => {
    const host = serviceHosts[index % serviceHosts.length];
    return { host, newIndex: (index + 1) % serviceHosts.length };
};
```

### Caching

Caching is applied only to GET requests and endpoints that are not blacklisted. For example, chat reading endpoints are blacklisted to avoid apparent 1-minute delay in message delivery, as the cache timeout is set to 60 seconds.

```JavaScript
const cachingBlacklist = [
    "/chatApp/utilities/status/",
    "/assetApp/utilities/status/",
    "/chats/"
];

const getCachingKey = (req) => {
    if (
        req.method !== "GET" || 
        cachingBlacklist.some((path) => req.originalUrl.startsWith(path))
    ) {
        return null;
    }

    let cachingKey = `get:${req.originalUrl}`;
    const username = req.headers["x-username"];

    if (username) {
        cachingKey += `:username=${username}`;
    }

    return cachingKey;
};
```

In the request handler, the gateway checks if a response is cached using the key provided by this method. If a cached response exists, it is returned immediately; otherwise, the gateway fetches the response from the server and caches it for future requests (for 60s).

### Endpoints

Gateway endpoints are automatically generated based on a predefined list of paths.

```JavaScript
const chatEndpoits = [
    "/chats/",
    "/chats/:chat_id/",
    "/chats/unseen-list/",
    "/messages/send-to-chat/:chat_id/",
    "/messages/:message_id/",
    "/messages/:message_id/mark-as-seen/",
    "/chatApp/utilities/status/"
];
const assetEndpoints = [
    "/assets/",
    "/assets/:asset_id/",
    "/assets/:asset_id/add-to-scene/:scene_id/",
    "/assets/list-for-scene/:scene_id/",
    "/assets/get-file-url/:asset_id/",
    "/scenes/",
    "/scenes/:scene_id/",
    "/assetApp/utilities/status/",
];

chatEndpoits.forEach((route) => {
    app.all(route, (req, res) => handleRequest(req, res, chatBases, chatIndex));
});

assetEndpoints.forEach((route) => {
    app.all(route, (req, res) => handleRequest(req, res, assetBases, assetIndex));
});
```

## Logging

Logging is managed using an ELK stack.

### Gateway

For logging in the gateway, Winston is used.

```JavaScript
const infoLogger = winston.createLogger({
    transports: [
        new winston.transports.Http({
            host: LOGSTASH_HOST,
            port: LOGSTASH_PORT,
            level: 'info',
        })
    ],
});

const errLogger = winston.createLogger({
    transports: [
        new winston.transports.Http({
            host: LOGSTASH_HOST,
            port: LOGSTASH_PORT,
            level: 'error'
        })
    ]
})

function logMsg(msg) {
    if (LOGGING) {
        infoLogger.info(JSON.stringify({
            "service": "gateway",
            "msg": msg
        }));
    }
}

function logErr(msg) {
    if (LOGGING) {
        errLogger.error(JSON.stringify({
            "service": "gateway",
            "error": msg
        }));
    }
}
```

For logging in the Django services, a custom middleware (appName.appName.middleware) was implemented to send all access logs to Logstash via HTTP. The middleware is designed to sit between the logic and the response in the following chain: request > logic > logging > response. It is configured to save access logs to Logstash and also log responses with status codes 'greater than' 400.

```Python
class LogstashLogger:
    def __init__(self):
        self.logstash_host = getenv('LOGSTASH_HOST')
        self.logstash_port = int(getenv('LOGSTASH_PORT'))
        self.service_name = getenv('SERVICE_NAME')

    def log(self, message, level='info'):
        try:
            log_data = {
                "service": self.service_name,
                "message": message,
                "timestamp": datetime.utcnow().isoformat(),
                "level": level
            }

            requests.post(
                f'http://{self.logstash_host}:{self.logstash_port}',
                json=log_data,
                headers={'Content-Type': 'application/json'},
                timeout=1
            )
        except Exception as e:
            print(f"Logging failed: {str(e)}")

    def info(self, message):
        self.log(message, 'info')

    def error(self, message):
        self.log(message, 'error')

    def warn(self, message):
        self.log(message, 'warn')

    def debug(self, message):
        self.log(message, 'debug')

logger = LogstashLogger()


class LoggingMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

        try:
            self.logging_enabled = int(getenv("LOGGING", "0"))
        except ValueError:
            self.logging_enabled = 0        

    def __call__(self, request):
        response = self.get_response(request)

        log_info = {
            "service": f"{logger.service_name}_{getenv('EXTERNAL_PORT')}",
        }

        error_detail = None
        if 400 <= response.status_code < 600:
            try:
                error_detail = json.loads(response.content)['detail']
            except Exception:
                error_detail = 'Unknown error'

            log_info['msg'] = f"ERROR: Request {request.method}:{request.path} - {response.status_code} : {error_detail}"
        else:
            log_info['msg'] = f"LOG: Request {request.method}:{request.path}"

        if self.logging_enabled:
            if not error_detail:
                logger.info(json.dumps(log_info))
            else:
                logger.error(json.dumps(log_info))
            
        return response
```

Indexes for seeing the logs in Kibana stream (http://localhost:5601/app/logs/stream) are: 

    gateway_logs-*,chat_service_logs-*,asset_service_logs-*,unknown_service_logs-*

## Presentation Points

1. Languadges: Python (Django REST framework) for the services / JavaScript (Express) for the API Gateway.

2. 3 replicas per service - visible in the docker-compsoe.yml and **Docker Desktop UI once deployed**. Also you could spam the status requests to get the status from all 3 replicas (each replica returns a response containing a different port, which it extracts from its environment variables).

3. To verify database separation, follow these steps in Docker Desktop UI:
    
    1. Open **chat-pg** or **asset-pg**
    
    2. Click **Exec** and execute the following command:
        
        ```
        psql -U chat/asset_user -d chat/asset_db
        ```

        \* If prompted for a password, enter: chat/asset_password
        
        \* These values can be found in docker-compose.yml under the DB environment variables

    3. Once connected, run:
        ```
        \dt
        ```
        You should see tables specific to the corresponding service:

        \* For chat-pg: chats_chat & cmessages_message
        
        \* For asset-pg: assets_asset & scenes_scene

4. All the status requests can be found in Postman.

5. Gateway is written in JavaScript (Express). The code is located in gateway/index.js, where, at the bottom, you can find the loop that registers all service-handled paths as gateway endpoints.

6. To check redis cache:

    1. Open **gateway-cache** container in the Docker Desktop

    2. Click **Exec** and execute the following command:

        ```
        redis-cli
        ```

    3. In the Redis CLI execute:

        ```
        KEYS *
        ```

        to list all the keys and

        ```
        GET <your-key>        
        ```

        to query a value by the key

    In Kibana, you can see the logs generated by the Gateway API when it retrieves data from the cache.

7. Load balancing implementation is described above. To verify this, repeatedly call the status endpoint—you will receive responses with different ports specified. Additionally, check Kibana for access logs from different services on each request.

8. To verify the work of the ELK stack:

    1. Navigate to: ```http://localhost:5601/app/logs/stream```
    
    4. Set up the indices as follows: ```gateway_logs-\*,chat_service_logs-\*,asset_service_logs-\*,unknown_service_logs-\*```

    5. Return to the **Logs/Stream**

    You should be able to see logs from both the services and the gateway.

9. ...

10. ...
