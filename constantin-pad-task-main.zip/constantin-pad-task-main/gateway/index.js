const express = require("express");
const axios = require("axios");
const redis = require("redis");
const winston = require('winston');

const app = express();
app.use(express.json());

require('dotenv').config();
const LOGGING = parseInt(process.env.LOGGING);
const LOGSTASH_HOST = process.env.LOGSTASH_HOST;
const LOGSTASH_PORT = process.env.LOGSTASH_PORT

const infoLogger = winston.createLogger({
    transports: [
        new winston.transports.Http({
            host: LOGSTASH_HOST,
            port: LOGSTASH_PORT,
            level: 'info',
        })
    ],
});

const errLogger = winston.createLogger({
    transports: [
        new winston.transports.Http({
            host: LOGSTASH_HOST,
            port: LOGSTASH_PORT,
            level: 'error'
        })
    ]
})

function logMsg(msg) {
    if (LOGGING) {
        infoLogger.info(JSON.stringify({
            "service": "gateway",
            "msg": msg
        }));
    }
}

function logErr(msg) {
    if (LOGGING) {
        errLogger.error(JSON.stringify({
            "service": "gateway",
            "error": msg
        }));
    }
}

const redisClient = redis.createClient({ url: process.env.REDIS_URL || "redis://gateway-cache:6379" });
redisClient.connect();

const chatBases = ["http://chat-1:8000", "http://chat-2:8000", "http://chat-3:8000"];
const assetBases = ["http://asset-1:8000", "http://asset-2:8000", "http://asset-3:8000"];
let chatIndex = 0;
let assetIndex = 0;

const getNextHost = (serviceHosts, index) => {
    const host = serviceHosts[index % serviceHosts.length];
    return { host, newIndex: (index + 1) % serviceHosts.length };
};

const cachingBlacklist = [
    "/chatApp/utilities/status/",
    "/assetApp/utilities/status/",
    "/chats/"
];

const getCachingKey = (req) => {
    if (
        req.method !== "GET" || 
        cachingBlacklist.some((path) => req.originalUrl.startsWith(path))
    ) {
        return null;
    }

    let cachingKey = `get:${req.originalUrl}`;
    const username = req.headers["x-username"];

    if (username) {
        cachingKey += `:username=${username}`;
    }

    return cachingKey;
};

const handleRequest = async (req, res, serviceHosts, indexTracker) => {
    const { host, newIndex } = getNextHost(serviceHosts, indexTracker);
    const cachingKey = getCachingKey(req);

    if (cachingKey) {
        try {
            const cachedResponse = await redisClient.get(cachingKey);
            if (cachedResponse) {
                logMsg(`LOG: Retrieving ${req.method}:${req.originalUrl} from cache`);
                return res.json(JSON.parse(cachedResponse));
            }
        } catch (error) {
            console.error("Redis error:", error);
        }
    }

    logMsg(`LOG: Requesting ${req.method}:${req.originalUrl} from ${host}`);

    const url = `${host}${req.originalUrl}`;
    try {
        const response = await axios({
            method: req.method,
            url: url,
            data: req.body,
            headers: req.headers
        });

        if (cachingKey) {
            await redisClient.setEx(cachingKey, 60, JSON.stringify(response.data));
        }

        res.status(response.status).json(response.data);
    } catch (error) {
        logErr(`ERR: Received ${error.response?.status || 500} response from ${new URL(url).hostname.split(':')[0]}`);

        res.status(error.response?.status || 500).json(error.response?.data || { detail: "Internal Server Error" });
    }

    if (serviceHosts === chatBases) {
        chatIndex = newIndex;
    } else {
        assetIndex = newIndex;
    }
};

const chatEndpoits = [
    "/chats/",
    "/chats/:chat_id/",
    "/chats/unseen-list/",
    "/messages/send-to-chat/:chat_id/",
    "/messages/:message_id/",
    "/messages/:message_id/mark-as-seen/",
    "/chatApp/utilities/status/"
];
const assetEndpoints = [
    "/assets/",
    "/assets/:asset_id/",
    "/assets/:asset_id/add-to-scene/:scene_id/",
    "/assets/list-for-scene/:scene_id/",
    "/assets/get-file-url/:asset_id/",
    "/scenes/",
    "/scenes/:scene_id/",
    "/assetApp/utilities/status/",
];

chatEndpoits.forEach((route) => {
    app.all(route, (req, res) => handleRequest(req, res, chatBases, chatIndex));
});

assetEndpoints.forEach((route) => {
    app.all(route, (req, res) => handleRequest(req, res, assetBases, assetIndex));
});

const PORT = 8080;

app.get('/status/', (req, res) => {
    res.status(200).json({ message: `API Gateway at 127.0.0.1:${PORT} is up and running` });
});

app.listen(PORT, () => {
    console.log(`Gateway running at 127.0.0.1:${PORT}`);
});