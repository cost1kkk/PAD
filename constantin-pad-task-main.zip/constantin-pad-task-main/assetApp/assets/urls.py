from django.urls import path
from .views import AssetView, AddAssetToSceneView, ListAssetsForScene, GetFileUrlView


urlpatterns = [
    path('', AssetView.as_view()),
    path('<int:pk>/', AssetView.as_view()),
    path('<int:pk>/add-to-scene/<int:scene_id>/', AddAssetToSceneView.as_view()),
    path('list-for-scene/<int:scene_id>/', ListAssetsForScene.as_view()),
    path('get-file-url/<int:pk>/', GetFileUrlView.as_view()),
]