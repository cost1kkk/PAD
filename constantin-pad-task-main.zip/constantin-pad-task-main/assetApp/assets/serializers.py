from rest_framework.serializers import ModelSerializer
from .models import Asset


class AssetListSerializer(ModelSerializer):
    class Meta:
        model = Asset
        fields = ['id', 'name']


class AssetSerializer(ModelSerializer):
    from scenes.serializers import SceneListSerizalizer
    scene = SceneListSerizalizer(many=True, required=False)

    class Meta:
        model = Asset
        fields = '__all__'

    def create(self, validated_data):
        scene = validated_data.pop('scene', None)
        asset = Asset.objects.create(**validated_data)
        
        if scene:
            asset.scene.set(scene)

        return asset
