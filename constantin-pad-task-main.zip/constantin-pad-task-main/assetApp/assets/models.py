from django.db import models
from scenes.models import Scene


class Asset(models.Model):
    name = models.CharField(max_length=256, blank=False)
    file_url = models.CharField(max_length=256, blank=False)
    scene = models.ManyToManyField(Scene, related_name='assets')
