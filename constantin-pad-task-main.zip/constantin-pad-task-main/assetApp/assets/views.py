from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from rest_framework import status
from .models import Asset
from scenes.models import Scene
from .serializers import AssetListSerializer, AssetSerializer
from rest_framework.views import APIView


class AssetView(GenericAPIView):
    queryset = Asset.objects.all()
    serializer_class = AssetSerializer

    def get(self, request, pk=None):
        if pk:
            instance = self.get_object()
            serializer = self.get_serializer(instance)
        else:
            instances = self.get_queryset()
            serializer = AssetListSerializer(instances, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def patch(self, request, pk):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request, pk):
        instance = self.get_object()
        instance.delete()
        
        return Response(status=status.HTTP_204_NO_CONTENT)


class AddAssetToSceneView(APIView):
    def post(self, request, pk, scene_id):
        try:
            scene_instance = Scene.objects.get(id=scene_id)
            asset_instance = Asset.objects.get(id=pk)
        except Scene.DoesNotExist:
            return Response({'detail': 'Scene not found.'}, status=status.HTTP_404_NOT_FOUND)
        except Asset.DoesNotExist:
            return Response({'detail': 'Asset not found.'}, status=status.HTTP_404_NOT_FOUND)
        
        scene_instance.assets.add(asset_instance)

        return Response(
            {'message': f'Asset#{pk} added to scene#{scene_id} successfully.'},
            status=status.HTTP_200_OK
        )


class ListAssetsForScene(GenericAPIView):
    queryset = Asset.objects.all()
    serializer_class = AssetListSerializer

    def get(self, request, scene_id):
        try:
            scene_instance = Scene.objects.get(id=scene_id)
        except Scene.DoesNotExist:
            return Response({'detail': 'Scene not found.'}, status=status.HTTP_404_NOT_FOUND)
        
        instaces = Asset.objects.filter(scene=scene_instance)
        serializer = self.get_serializer(instaces, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)


class GetFileUrlView(APIView):
    def get(self, request, pk):
        try:
            instance = Asset.objects.get(id=pk)
        except Asset.DoesNotExist:
            return Response({'detail': 'Asset not found.'}, status=status.HTTP_404_NOT_FOUND)
        
        return Response({'file_url': instance.file_url}, status=status.HTTP_200_OK)
