from django.db import models


class Scene(models.Model):
    name = models.CharField(max_length=256, blank=False)
