from .models import Scene
from rest_framework.serializers import ModelSerializer


class SceneListSerizalizer(ModelSerializer):
    class Meta:
        model = Scene
        fields = ['id', 'name']


class SceneSerializer(ModelSerializer):
    from assets.serializers import AssetListSerializer
    assets = AssetListSerializer(many=True, read_only=True)
    
    class Meta:
        model = Scene
        fields = '__all__'
