from django.urls import path
from .views import SceneView


urlpatterns = [
    path('', SceneView.as_view()),
    path('<int:pk>/', SceneView.as_view()),
]