from .models import Scene
from .serializers import SceneListSerizalizer, SceneSerializer
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from rest_framework import status


class SceneView(GenericAPIView):
    queryset = Scene.objects.all()
    serializer_class = SceneSerializer

    def get(self, request, pk=None):
        if pk:
            instance = self.get_object()
            serialzier = self.get_serializer(instance)
        else:
            instances = self.get_queryset()
            serialzier = SceneListSerizalizer(instances, many=True)

        return Response(serialzier.data, status=status.HTTP_200_OK)
    
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def patch(self, request, pk):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request, pk):
        instance = self.get_object()
        instance.delete()
        
        return Response(status=status.HTTP_204_NO_CONTENT)
    