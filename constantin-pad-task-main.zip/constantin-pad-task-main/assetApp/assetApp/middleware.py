import json
import requests
from datetime import datetime
from os import getenv


class LogstashLogger:
    def __init__(self):
        self.logstash_host = getenv('LOGSTASH_HOST')
        self.logstash_port = int(getenv('LOGSTASH_PORT'))
        self.service_name = getenv('SERVICE_NAME')

    def log(self, message, level='info'):
        try:
            log_data = {
                "service": self.service_name,
                "message": message,
                "timestamp": datetime.utcnow().isoformat(),
                "level": level
            }

            requests.post(
                f'http://{self.logstash_host}:{self.logstash_port}',
                json=log_data,
                headers={'Content-Type': 'application/json'},
                timeout=1
            )
        except Exception as e:
            print(f"Logging failed: {str(e)}")

    def info(self, message):
        self.log(message, 'info')

    def error(self, message):
        self.log(message, 'error')

    def warn(self, message):
        self.log(message, 'warn')

    def debug(self, message):
        self.log(message, 'debug')

logger = LogstashLogger()


class LoggingMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

        try:
            self.logging_enabled = int(getenv("LOGGING", "0"))
        except ValueError:
            self.logging_enabled = 0        

    def __call__(self, request):
        response = self.get_response(request)

        log_info = {
            "service": f"{logger.service_name}_{getenv('EXTERNAL_PORT')}",
        }

        error_detail = None
        if 400 <= response.status_code < 600:
            try:
                error_detail = json.loads(response.content)['detail']
            except Exception:
                error_detail = 'Unknown error'

            log_info['msg'] = f"ERROR: Request {request.method}:{request.path} - {response.status_code} : {error_detail}"
        else:
            log_info['msg'] = f"LOG: Request {request.method}:{request.path}"

        if self.logging_enabled:
            if not error_detail:
                logger.info(json.dumps(log_info))
            else:
                logger.error(json.dumps(log_info))
            
        return response
