from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from os import getenv


class StatusView(APIView):
    def get(self, request):
        return Response(
            {"message": f"Asset-service at 127.0.0.1:{getenv("EXTERNAL_PORT")} is up and running"},
            status=status.HTTP_200_OK
        )
