from rest_framework.views import APIView
from rest_framework.response import Response
from os import getenv
from rest_framework import status


class StatusView(APIView):
    def get(self, request):
        return Response(
            {"message": f"Chat-service at 127.0.0.1:{getenv("EXTERNAL_PORT")} is up and running"},
            status=status.HTTP_200_OK
        )
