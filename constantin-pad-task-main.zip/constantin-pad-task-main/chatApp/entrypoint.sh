#!/bin/bash
set -e

# Wait for databases to fully start
echo "Waiting 15s for the db to become available..."
sleep 15

# Check if the environment variable RUN_MIGRATIONS is set to "true"
if [ "$RUN_MIGRATIONS" == "true" ]; then
    echo "Running migrations..."
    python manage.py migrate --noinput
else
    echo "Skipping migrations (RUN_MIGRATIONS is set to false)"
fi

# Start the application
exec gunicorn --bind 0.0.0.0:8000 chatApp.wsgi:application --reload --access-logfile '-'