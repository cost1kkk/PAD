from django.db import models
from django.contrib.postgres.fields import ArrayField
from chats.models import Chat


class Message(models.Model):
    chat = models.ForeignKey(Chat, on_delete=models.CASCADE, related_name='messages')
    msg = models.TextField(blank=False)
    sender_username = models.CharField(max_length=256, blank=False)
    private = ArrayField(models.CharField(max_length=256), blank=True, default=list)
    seen = ArrayField(models.CharField(max_length=256), blank=True, default=list)
    sent_at = models.DateTimeField(auto_now_add=True)
