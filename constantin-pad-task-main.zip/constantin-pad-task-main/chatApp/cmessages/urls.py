from django.urls import path
from .views import MessageView, MarkAsSeenView


urlpatterns = [
    path('send-to-chat/<int:chat_id>/', MessageView.as_view()),
    path('<int:pk>/', MessageView.as_view()),
    path('<int:pk>/mark-as-seen/', MarkAsSeenView.as_view()),
]
