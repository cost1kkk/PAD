from rest_framework.generics import GenericAPIView
from .models import Message
from .serializers import MessageSerializer
from rest_framework.response import Response
from chats.models import Chat
from rest_framework import status


class MessageView(GenericAPIView):
    queryset = Message.objects.all()
    serializer_class = MessageSerializer

    def post(self, request, chat_id):
        username = request.headers.get('X-Username')
        if not username:
            return Response({"detail": "X-Username header is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            chat = Chat.objects.get(id=chat_id)
        except Chat.DoesNotExist:
            return Response({"detail": "Chat not found."}, status=status.HTTP_404_NOT_FOUND)
        
        data = request.data.copy()
        data['chat'] = chat.id

        serializer = self.get_serializer(data=data)
        if serializer.is_valid(raise_exception=True):
            serializer.save(sender_username=username)

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
    def patch(self, request, pk):
        username = request.headers.get('X-Username')
        if not username:
            return Response({"detail": "X-Username header is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        instance = self.get_object()
        if username != instance.sender_username:
            return Response({"detail": "You are not allowed to do that."}, status=status.HTTP_403_FORBIDDEN)

        serializer = self.get_serializer(instance, data=request.data, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()

            return Response(serializer.data, status=status.HTTP_200_OK)
        
    def delete(self, request, pk):
        username = request.headers.get('X-Username')
        if not username:
            return Response({"detail": "X-Username header is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        instance = self.get_object()
        if username != instance.sender_username:
            return Response({"detail": "You are not allowed to do that."}, status=status.HTTP_403_FORBIDDEN)

        instance.delete()

        return Response(status=status.HTTP_204_NO_CONTENT)


class MarkAsSeenView(GenericAPIView):
    def patch(self, request, pk):
        username = request.headers.get('X-Username')
        if not username:
            return Response({"detail": "X-Username header is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            message = Message.objects.get(id=pk)
        except Message.DoesNotExist:
            return Response({"detail": "Message not found."}, status=status.HTTP_404_NOT_FOUND)
        
        if username not in message.seen:
            message.seen.append(username)
            message.save()

        return Response(status=status.HTTP_204_NO_CONTENT)
