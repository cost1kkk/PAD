from rest_framework.serializers import ModelSerializer
from .models import Chat
from cmessages.serializers import MessageSerializer


class ChatSerializer(ModelSerializer):
    messages = MessageSerializer(many=True, read_only=True)

    class Meta:
        model = Chat
        fields = '__all__'


class ChatListSerializer(ModelSerializer):
    class Meta:
        model = Chat
        fields = ['id', 'name']
