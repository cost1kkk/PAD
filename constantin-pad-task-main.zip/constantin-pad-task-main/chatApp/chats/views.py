from rest_framework.generics import GenericAPIView, ListAPIView
from rest_framework.response import Response
from rest_framework import status
from .models import Chat
from .serializers import ChatSerializer, ChatListSerializer
from django.db.models import Subquery, OuterRef
from cmessages.models import Message


class ChatView(GenericAPIView):
    queryset = Chat.objects.all()
    serializer_class = ChatSerializer

    def get(self, request, pk=None):
        if pk:
            username = request.headers.get('X-Username')
            if not username:
                return Response({"detail": "X-Username header is required."}, status=status.HTTP_400_BAD_REQUEST)

            instance = self.get_object()
            serializer = self.get_serializer(instance)

            data = serializer.data
            data['messages'] = [
                msg for msg in data['messages']
                if not msg['private'] or username in msg['private']
            ]

            for message in data['messages']:
                message.pop('chat', None)
                message.pop('private', None)
        else:
            instances = self.get_queryset()
            serializer = ChatListSerializer(instances, many=True)
            data = serializer.data

        return Response(data, status=status.HTTP_200_OK)
    
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def patch(self, request, pk):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request, pk):
        instance = self.get_object()
        instance.delete()
        
        return Response(status=status.HTTP_204_NO_CONTENT)


class UnseenChatListView(ListAPIView):
    serializer_class = ChatListSerializer

    def get_queryset(self):
        return Chat.objects.filter(
            messages__isnull=False
        ).annotate(
            latest_message_id=Subquery(
                Message.objects.filter(
                    chat=OuterRef('pk')
                ).order_by('-sent_at').values('id')[:1]
            ),
            latest_message_seen=Subquery(
                Message.objects.filter(
                    chat=OuterRef('pk')
                ).order_by('-sent_at').values('seen')[:1]
            )
        ).exclude(
            latest_message_seen__contains=[self.username]
        ).distinct()

    def list(self, request, *args, **kwargs):
        username = self.request.headers.get('X-Username')
        if not username:
            return Response({"detail": "X-Username header is required."}, status=status.HTTP_400_BAD_REQUEST)
        self.username = username
        
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
