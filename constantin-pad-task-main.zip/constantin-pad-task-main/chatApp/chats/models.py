from django.db import models


class Chat(models.Model):
    name = models.CharField(max_length=256, blank=False)
    created_at = models.DateField(auto_now_add=True)
