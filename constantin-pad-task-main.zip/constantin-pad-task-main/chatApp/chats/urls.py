from django.urls import path
from .views import ChatView, UnseenChatListView


urlpatterns = [
    path('', ChatView.as_view()),
    path('<int:pk>/', ChatView.as_view()),
    path('unseen-list/', UnseenChatListView.as_view()),
]
